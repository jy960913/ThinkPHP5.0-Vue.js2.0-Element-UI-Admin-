import Vue from 'vue'
import Router from 'vue-router'
import store from '@/store/store'
import Header from '@/components/common/header'
import Nav from '@/components/common/nav'
import Main from '@/components/common/main'
import Home from '@/components/common/home'
import Buttons from '@/components/page/button'
import Radios from '@/components/page/radio'
import Checkboxs from '@/components/page/checkbox'
import Inputs from '@/components/page/input'
import Inputnumber from '@/components/page/inputnumber'
import Datepicker from '@/components/page/datepicker'
import Custom from '@/components/page/custom'
import Auth from '@/components/page/auth'
import Role from '@/components/page/role'
import Login from '@/components/page/login'
import Echarts from '@/components/page/echarts'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/login', name:'登录',component: Login
    },
    {
      path: '/',component: Home,
      children:[{
      	path: '/',name:'首页', component: Main,
      }]
    },
    {
      path: '/home',component: Home,
      children:[{
        path: '/echarts',name:'ECharts', component: Echarts,
      }]
    },
    {
      path: '/home',name:"基础组件",component: Home,
      children: [
        {
          path: '/button',name:'Button 按钮', component: Buttons,
        },
        {
          path: '/radio',name:'Radio 单选框', component: Radios,
        },
        {
          path: '/checkbox',name:'Checkbox 多选框', component: Checkboxs,
        },
        {
          path: '/inputs',name:'Input 输入框', component: Inputs,
        },
        {
          path: '/inputnumber',name:'InputNumber 计数器', component: Inputnumber,
        },
        {
          path: '/datepicker',name:'DatePicker 日期选择器', component: Datepicker,
        },
      ],
    },
    {
      path: '/home',name:"权限管理",component: Home,
      children: [
        {
          path: '/auth',name:'用户管理', component: Auth,
        },
        {
          path: '/role',name:'角色管理', component: Role,
        },
      ],
    },
    {
      path: '/home',component: Home,
      children: [
        {
          path: '/custom',name:'自定义主题', component: Custom,
        },
      ],
    },
  ]
});
// 页面刷新时，重新赋值token
if ( window.localStorage.getItem('textcolor') ) {
    store.commit('textcolor', window.localStorage.getItem('textcolor'));
};
if ( window.localStorage.getItem('activecolor') ) {
    store.commit('activecolor', window.localStorage.getItem('activecolor'));
};
if ( window.localStorage.getItem('bgcolor') ) {
    store.commit('bgcolor', window.localStorage.getItem('bgcolor'));
};
if ( window.localStorage.getItem('tbgcolor') ) {
    store.commit('tbgcolor', window.localStorage.getItem('tbgcolor'));
};
if ( window.localStorage.getItem('tactivecolor') ) {
    store.commit('tactivecolor', window.localStorage.getItem('tactivecolor'));
};
if ( window.localStorage.getItem('ttextcolor') ) {
    store.commit('ttextcolor', window.localStorage.getItem('ttextcolor'));
};
if ( window.localStorage.getItem('navlist') ) {
    store.commit('navlist', window.localStorage.getItem('navlist'));
};
if ( window.localStorage.getItem('nav_arr') ) {
    store.commit('nav_arr', window.localStorage.getItem('nav_arr'));
};
if ( window.localStorage.getItem('admin') ) {
    store.commit('admin', window.localStorage.getItem('admin'));
};
