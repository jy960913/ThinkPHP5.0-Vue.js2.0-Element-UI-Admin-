<template>
  <div>
  	<div style="padding-bottom:15px;">
  		<el-button round icon="el-icon-circle-plus" type="primary" @click="addroles">添加角色</el-button>
  	</div>
   	<div>
   		<el-table
        v-loading="loading2"
		    :data="tableData.slice((currentPage4-1)*pagesize,currentPage4*pagesize)"
		    style="width: 100%;border:1px solid #ebebeb;border-radius:3px;transition:.2s;">
		    <el-table-column
		      type="selection"
		      width="55">
		    </el-table-column>
		    <el-table-column
		      prop="dates"
		      label="添加时间"
		      sortable
		      width="180">
		    </el-table-column>
		    <el-table-column
		      prop="names"
		      label="角色名称"
		      width="180">
		    </el-table-column>
		    <el-table-column label="操作">
		      <template slot-scope="scope">
		        <el-button
		          size="mini"
		          @click="handleEdit(scope.row)">编辑</el-button>
		        <el-button
		          size="mini"
		          type="danger"
		          @click="handleDelete(scope.row)">删除</el-button>
		          <el-button
		          size="mini"
		          type="success"
		          @click="handleauth(scope.row)">权限</el-button>
		      </template>
		    </el-table-column>
		  </el-table>
   	</div>
    <div style="padding-top:20px;float:right;">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage4"
        :page-sizes="[10, 20, 30, 40]"
        :page-size="pagesize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="tableData.length">
      </el-pagination>
    </div>
   	<div>
   		<el-dialog title="添加角色" :visible.sync="dialogFormVisible">
		  <el-form :model="form" :rules="rules" ref="form">
		    <el-form-item label="角色名称" :label-width="formLabelWidth" prop="names">
		      <el-input v-model="form.names" style="width:80%" auto-complete="off"></el-input>
		    </el-form-item>
		  </el-form>
		  <div slot="footer" class="dialog-footer">
		    <el-button @click="dialogFormVisible = false">取 消</el-button>
		    <el-button type="primary" @click.native.prevent="addrole('form')" :loading="logining">确 定</el-button>
		  </div>
		</el-dialog>
   	</div>
   	<div>
   		<el-dialog title="编辑角色" :visible.sync="editdialogFormVisible">
		  <el-form :model="form" :rules="rules" ref="form">
		    <el-form-item label="角色名称" :label-width="formLabelWidth" prop="names">
		      <el-input v-model="form.names" style="width:80%" auto-complete="off"></el-input>
		    </el-form-item>
		  </el-form>
		  <div slot="footer" class="dialog-footer">
		    <el-button @click="editdialogFormVisible = false">取 消</el-button>
		    <el-button type="primary" @click.native.prevent="editrole('form')" :loading="logining">确 定</el-button>
		  </div>
		</el-dialog>
   	</div>
   	<div>
   		<el-dialog title="权限" :close-on-click-modal='false' :show-close='false' :close-on-press-escape='false' :visible.sync="authdialogFormVisible">
		  	<el-tree
			  :data="data2"
			  show-checkbox
			  default-expand-all
			  node-key="id"
			  ref="tree"
			  highlight-current
			  :props="defaultProps">
			</el-tree>
			<div slot="footer" class="dialog-footer">
		    	<el-button @click="guanbi()">取 消</el-button>
		    	<el-button type="primary" @click="addrole_auth" :loading="logining">保 存</el-button>
		  	</div>
		</el-dialog>
   	</div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        currentPage4: 1,
        pagesize:10,
        loading2: false,
      	logining: false,
        tableData: [],
        dialogFormVisible: false,
        editdialogFormVisible:false,
        authdialogFormVisible:false,
        form: {
          names: '',
          rid:'',
        },
        rules: {
          names: [
            { required: true, message: '请输入角色名称', trigger: 'blur' },
            { min: 3, max: 6, message: '长度在 3 到 6 个字符', trigger: 'blur' }
          ],
        },
        formLabelWidth: '120px',
        data2: [],
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        rid:'',
      }
    },
    created(){
      this.getrolelist(),
      this.getnavlist()
    },
    methods: {
      handleSizeChange(val) {
        this.pagesize = val;
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        this.currentPage4 = val;
        console.log(`当前页: ${val}`);
      },
    	//关闭权限弹窗并清空权限
    	guanbi(){
    		this.$nextTick(()=>{
      			this.$refs.tree.setCheckedKeys([]);
      		});
    		this.authdialogFormVisible = false;
    	},
    	addrole_auth() {
    		var datas = this.$refs.tree.getCheckedNodes();
    		var arr = [];
    		for (var i = this.$refs.tree.getCheckedNodes().length - 1; i >= 0; i--) {
    			var id  = datas[i]['id'];
    			var isid =  arr.indexOf(id);
    			if (isid == -1) {
    				arr.push(id);
    			};
    			var pid = parseInt(datas[i]['pid']);
    			var ispid =  arr.indexOf(pid);
    			if (ispid == -1 && pid != 0) {
    				arr.push(pid);
    			};
    		};
	       var that = this;
	       that.logining = true;
	       that.axios.post('addrole_auth', {
     				rid: that.rid,
     				aid: arr, //真正左侧菜单数组
            showaid: that.$refs.tree.getCheckedKeys(),//只为了展示看
        	})
        	.then(function (response) {
        		that.logining = false;
          		if (response.data.isok == 1) {
            		that.authdialogFormVisible = false;
            		that.$message({
              		type: 'success',
              			message: '权限设置成功!'
            		});    
          		}else{
            		that.authdialogFormVisible = false;
            		that.$message({
              			type: 'warning',
              			message: '您没有修改权限!'
            		});
          		};
        	})
        	.catch(function (error) {
          		console.log(error);
        	});
	    },
      handleEdit(row) {
        console.log(row);
        this.editdialogFormVisible = true;
        this.form.names = row.names;
        this.form.rid = row.rid;
      },
      handleauth(row){
      		var that = this;
      		that.rid = row.rid;
      		that.authdialogFormVisible = true;
        	that.axios.get('getauthlist', {
          		params: {
 					      rid:row.rid,
          		}
        	})
        	.then(function (response) {
        		//有则返回 无则返回空数组
    			that.$nextTick(()=>{
	      			that.$refs.tree.setCheckedKeys(response.data.list);
	      		});
        	})
        	.catch(function (error) {
          		console.log(error);
        	});
      },
      addroles(){
      		this.dialogFormVisible = true;
      		this.form.names = '';
      },
      handleDelete(row) {
        var that = this;
        that.$confirm('此操作将永久删除, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          that.axios.get('deleterole',{
            params:{
              rid: row.rid,
            }
          })
          .then(function(response){
            if (response.data.isok == 1) {
              that.getrolelist();
              that.$message({
                type: 'success',
                message: '删除成功!'
              });
            } else {
            	that.getrolelist();
	            that.$message({
	               type: 'error',
	               message: '删除失败!'
	            });
            };
            
          })
          .catch(function(err){
            console.log(err);
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
      },
        //添加角色
        addrole(form){
        	var that = this;
        	that.$refs[form].validate((valid) => {
	          if (valid) {
		        	that.logining = true;
		        	that.axios.post('addrole', {
		 				names: that.form.names,
		        	})
		        	.then(function (response) {
		        		that.logining = false;
		          		if (response.data.isok == 1) {
		            		that.dialogFormVisible = false;
		            		that.getrolelist();
		            		that.form.names="";
		            		that.$message({
		              			type: 'success',
		              			message: '添加成功!'
		            		});    
		          		}else{
		            		that.dialogFormVisible = false;
		            		that.getrolelist()
		            		that.form.names="";
		            		that.$message({
		              			type: 'error',
		              			message: '添加失败!'
		            		});
		          		};
		        	})
		        	.catch(function (error) {
		          		console.log(error);
		        	});
	          } else {
	            console.log('error submit!!');
	            return false;
	          }
	        });
      	},
      	//编辑角色
        editrole(form){
        	var that = this;
        	that.$refs[form].validate((valid) => {
	          if (valid) {
		        	that.logining = true;
		        	that.axios.post('editrole', {
		 				names: that.form.names,
		 				rid: that.form.rid,
		        	})
		        	.then(function (response) {
		        		that.logining = false;
		          		if (response.data.isok == 1) {
		            		that.editdialogFormVisible = false;
		            		that.getrolelist();
		            		that.form.names="";
		            		that.form.rid="";
		            		that.$message({
		              			type: 'success',
		              			message: '编辑成功!'
		            		});
		          		}else{
		            		that.editdialogFormVisible = false;
		            		that.getrolelist()
		            		that.form.names="";
		            		that.form.rid="";
		            		that.$message({
					          message: '没有编辑新内容',
					          type: 'warning'
					        });
		          		};
		        	})
		        	.catch(function (error) {
		          		console.log(error);
		        	});
	          } else {
	            console.log('error submit!!');
	            return false;
	          }
	        });
      	},
      	//获取角色列表
      	getrolelist(){
      		var that = this;
          that.loading2 = true;
        	that.axios.get('getrolelist', {
          		params: {
 
          		}
        	})
        	.then(function (response) {
          		that.tableData=response.data.list;
              that.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                that.loading2 = false;
              });
        	})
        	.catch(function (error) {
          		console.log(error);
        	});
      	},
      	//获取左侧菜单列表
	      getnavlist(){
	        var that = this;
	        var isnavlist = that.$store.state.navlist;
	        if (isnavlist != '') {
	        	that.data2=JSON.parse(isnavlist);
	        } else {
	        	that.axios.get('getnav', {
		            params: {

		            }
		        })
		        .then(function (response) {
		        	console.log(response.data.navlist);
		            that.data2=response.data.navlist;
		            that.$store.commit('navlist', JSON.stringify(response.data.navlist));
		        })
		        .catch(function (error) {
		            console.log(error);
		        });
	        };
	      },
    }
  }
</script>

<style scoped>
</style>