<template>
  <div>
  	<div style="padding-bottom:15px;">
  		<el-button round icon="el-icon-circle-plus" type="primary" @click="dialogFormVisible = true">添加用户</el-button>
  	</div>
   	<div>
   		<el-table
		    :data="tableData"
		    style="width: 100%;border:1px solid #ebebeb;border-radius:3px;transition:.2s;">
		    <el-table-column
		      type="selection"
		      width="55">
		    </el-table-column>
		    <el-table-column
		      prop="add_time"
		      label="添加时间"
		      sortable
		      width="180">
		    </el-table-column>
		    <el-table-column
		      prop="admin"
		      label="账号"
		      width="180">
		    </el-table-column>
        <el-table-column
          prop="pwd"
          label="密码"
          width="180">
        </el-table-column>
		    <el-table-column label="操作">
		      <template slot-scope="scope">
		        <el-button
		          size="mini"
		          @click="handleEdit(scope.row)">编辑</el-button>
		        <el-button
		          size="mini"
		          type="danger"
		          @click="handleDelete(scope.row)">删除</el-button>
		          <el-button
		          size="mini"
		          type="success"
		          @click="userroles(scope.row)">角色</el-button>
		      </template>
		    </el-table-column>
		  </el-table>
   	</div>
    <div>
      <el-dialog title="添加用户" :visible.sync="dialogFormVisible">
        <el-form :model="form" :rules="rules" ref="form">
          <el-form-item label="账号" :label-width="formLabelWidth" prop="admin">
            <el-input v-model="form.admin" style="width:80%" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="密码" :label-width="formLabelWidth" prop="pwd">
            <el-input type="password" style="width:80%" v-model="form.pwd" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="确认密码" :label-width="formLabelWidth" prop="rpwd">
            <el-input type="password" style="width:80%" v-model="form.rpwd" auto-complete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="resetForm('form')">取 消</el-button>
          <el-button type="primary" @click.native.prevent="addusers('form')" :loading="logining">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div>
      <el-dialog title="编辑用户" :visible.sync="editdialogFormVisible">
        <el-form :model="form" :rules="rules" ref="form">
          <el-form-item label="账号" :label-width="formLabelWidth" prop="admin">
            <el-input v-model="form.admin" style="width:80%" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="密码" :label-width="formLabelWidth" prop="pwd">
            <el-input type="password" style="width:80%" v-model="form.pwd" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="确认密码" :label-width="formLabelWidth" prop="rpwd">
            <el-input type="password" style="width:80%" v-model="form.rpwd" auto-complete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="resetForm('form')">取 消</el-button>
          <el-button type="primary" @click.native.prevent="editusers('form')" :loading="logining">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div>
      <el-dialog title="角色" :visible.sync="userrole">
        <div>
          <el-transfer
            filterable
            :filter-method="filterMethod"
            :titles="['总列表', '已拥有']"
            :props="{
              key: 'rid',
              label: 'names'
            }"
            @change="handleChange"
            filter-placeholder="请输入城市拼音"
            v-model="value2"
            :data="data2">
          </el-transfer>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button @click="userrole = false">取 消</el-button>
          <el-button type="primary" @click="adduserrole()" :loading="logining">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.form.rpwd !== '') {
            this.$refs.form.validateField('rpwd');
          }
          callback();
        }
      };
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.form.pwd) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
      return {
        logining: false,
        rightrid:[],//右侧公共角色rid
        uid:'',//右侧公共用户uid
        data2: [],
        value2: [],
        filterMethod(query, item) {
          return item.names.indexOf(query) > -1;
        },
        logining: false,
        formLabelWidth: '120px',
        dialogFormVisible: false,
        editdialogFormVisible: false,
        userrole: false,
        form: {
          admin: '',
          pwd:'',
          rpwd:'',
          uid:'',
        },
        rules: {
          admin: [
            { required: true, message: '请输入账号', trigger: 'blur' },
            { min: 3, max: 6, message: '长度在 3 到 6 个字符', trigger: 'blur' }
          ],
          pwd: [
            { required: true, validator: validatePass, trigger: 'blur' }
          ],
          rpwd: [
            { required: true, validator: validatePass2, trigger: 'blur' }
          ],
        },
        tableData: []
      }
    },
    created(){
      this.getuserlist()
      this.rolelist()
    },
    methods: {
      //添加用户对应的角色
      adduserrole(){
        var that = this;
        that.logining = true;
        that.axios.post('adduser_role', {
            uid: that.uid,
            rid: that.rightrid,
        })
        .then(function (response) {
          that.logining = false;
            if (response.data.isok == 1) {
              that.userrole = false;
              that.$message({
                type: 'success',
                  message: '角色设置成功!'
              });    
            }else{
              that.userrole = false;
              that.$message({
                  type: 'warning',
                  message: '您没有修改角色!'
              });
            };
        })
        .catch(function (error) {
            console.log(error);
        });
      },
      //当角色左侧变化时
      handleChange(value, direction, movedKeys) {
        console.log(value, direction, movedKeys);
        this.rightrid=value;
      },
      //角色
      userroles(row){
          this.userrole=true;
          var that = this;
          that.uid = row.uid;
          that.axios.get('getuserrole', {
              params: {
                uid:row.uid,
              }
          })
          .then(function (response) {
            //有则返回 无则返回空数组
            that.value2 = response.data.list;
          })
          .catch(function (error) {
              console.log(error);
          });
      },
      //获取角色列表
      rolelist(){
        var that = this;
        that.axios.get('getrolelist', {
            params: {

            }
        })
        .then(function (response) {
            that.data2=response.data.list;
        })
        .catch(function (error) {
            console.log(error);
        });
      },
      resetForm(form) {
        this.$refs[form].resetFields();
        this.form.admin = '';
        this.form.pwd = '';
        this.form.rpwd = '';
        this.form.uid = '';
        this.dialogFormVisible=false;
        this.editdialogFormVisible=false;
      },
      //添加用户
      addusers(form){
        var that = this;
        that.$refs[form].validate((valid) => {
          if (valid) {
            that.logining = true;
            that.axios.post('addusers', {
                admin: that.form.admin,
                pwd: that.form.pwd,
            })
            .then(function (response) {
                that.logining = false;
                if (response.data.isok == 1) {
                  that.getuserlist();
                  that.resetForm(form);
                  that.$message({
                      type: 'success',
                      message: '添加成功'
                  });    
                } else if(response.data.isok == 2){
                  that.getuserlist();
                  that.resetForm(form);
                  that.$message({
                      type: 'warning',
                      message: '账号和密码已存在'
                  });
                }else{
                  that.getuserlist();
                  that.resetForm(form);
                  that.$message({
                      type: 'error',
                      message: '添加失败'
                  });
                };
            })
            .catch(function (error) {
                console.log(error);
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      //获取用户列表
      getuserlist(){
        var that = this;
        that.axios.get('getuserlist', {
            params: {

            }
        })
        .then(function (response) {
            that.tableData=response.data.list;
        })
        .catch(function (error) {
            console.log(error);
        });
      },
      handleEdit(row) {
        this.editdialogFormVisible = true;
        this.form.admin = row.admin;
        this.form.pwd = row.pwd;
        this.form.rpwd = row.pwd;
        this.form.uid = row.uid;
      },
      //删除角色
      handleDelete(row) {
        var that = this;
        that.$confirm('此操作将永久删除, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          that.axios.get('deleteuser',{
            params:{
              uid: row.uid,
            }
          })
          .then(function(response){
            if (response.data.isok == 1) {
              that.getuserlist();
              that.$message({
                type: 'success',
                message: '删除成功'
              });
            } else {
              that.getuserlist();
              that.$message({
                 type: 'error',
                 message: '删除失败'
              });
            };
            
          })
          .catch(function(err){
            console.log(err);
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
      },
      //编辑角色
      editusers(form){
        var that = this;
        that.$refs[form].validate((valid) => {
          if (valid) {
            that.logining = true;
            that.axios.post('edituser', {
                admin: that.form.admin,
                pwd: that.form.pwd,
                uid: that.form.uid,
            })
            .then(function (response) {
              that.logining = false;
                if (response.data.isok == 1) {
                  that.getuserlist();
                  that.resetForm(form);
                  that.$message({
                      type: 'success',
                      message: '编辑成功'
                  });
                }else{
                  that.getuserlist();
                  that.resetForm(form);
                  that.$message({
                    message: '没有编辑新内容',
                    type: 'warning'
                });
                };
            })
            .catch(function (error) {
                console.log(error);
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
    }
  }
</script>

<style scoped>
</style>